
import java.awt.Point;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ObjectReadWrite {

    public void saveObjects() {
        try {
            File file = new File("objects.data");
            FileOutputStream out = new FileOutputStream(file);
            ObjectOutputStream outObj = new ObjectOutputStream(out);

            // save objects to a file
            System.out.println("Saving objects to file " + file.getAbsolutePath());

            Point HKlocation = new Point(23, 114);
            JFrame window = new JFrame("Save a window object to a file!");
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            double[] rainfall = new double[12];
            rainfall[rainfall.length-1] = Math.PI;
            int[] mark = {99, 100, 80, 85};

            outObj.writeObject(HKlocation);
            outObj.writeObject(window);
            outObj.writeObject(rainfall);
            outObj.writeObject(mark);

            outObj.close();
        } catch (FileNotFoundException e) {
            System.out.println("File cannot be opened!");
        } catch (IOException e) {
            System.out.println("I/O error! Program exit.");
        }
    }

    public void loadObjects() {
        try {
            File file = new File("objects.data");
            FileInputStream in = new FileInputStream(file);
            ObjectInputStream inObj = new ObjectInputStream(in);

            // load objects from a file
            System.out.println("Loading objects from file " + file.getAbsolutePath());
            Point HKgps = (Point) inObj.readObject();
            JFrame win = (JFrame) inObj.readObject();
            double[] rain = (double[]) inObj.readObject();
            int[] mark = (int[]) inObj.readObject();

            win.setSize(600 + HKgps.x, HKgps.y);
            win.setTitle(win.getTitle() + "  With HK Location (" + HKgps.x + ", " + HKgps.y + ")");
            win.add(new JLabel("rainfall[11] = " + rain[11] + ", mark[2] = " + mark[2]));
            win.setVisible(true);

            inObj.close();
        } catch (FileNotFoundException e) {
            System.out.println("File cannot be opened!");
        } catch (ClassNotFoundException e) {
            System.out.println("Wrong Object type!");
        } catch (IOException e) {
            System.out.println("I/O error! Program exit.");
        }

    }

    public static void main(String[] args) {
        ObjectReadWrite testObj = new ObjectReadWrite();
        testObj.saveObjects();
        testObj.loadObjects();
    }
}
