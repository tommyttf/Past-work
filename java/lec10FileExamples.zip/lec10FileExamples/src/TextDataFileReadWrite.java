import java.io.File;
import java.io.PrintStream;
import java.util.Scanner;

public class TextDataFileReadWrite {

    private void writeData(PrintStream outStream) {
        int i;
        double d;
        boolean b;
        String s;
        b = (d = i = 3) == 3.1;
        s = "Hello";

        outStream.println(i);
        outStream.println(d);
        outStream.println(b);
        outStream.println(s);
    }

    public void saveData() throws Exception {
        File file = new File("data.txt");
        PrintStream ps = new PrintStream(file);
        // save data to a file
        System.out.println("Saving data to file " + file.getAbsolutePath());
        writeData(ps);

        System.out.println("These are what have been saved:");
        writeData(System.out);

        ps.close();

    }

    public void loadData() throws Exception {
        File file = new File("data.txt");
        Scanner dataSource = new Scanner(file);
        // load data from a file
        System.out.println("Loading data from file " + file.getAbsolutePath());
        int i = dataSource.nextInt();
        double d = dataSource.nextDouble();
        boolean b = dataSource.nextBoolean();
        String s = dataSource.next();
        dataSource.close();

        System.out.printf("i = %d, d = %f, b = %b, s = [%s]\n", i, d, b, s);

    }

    public static void main(String[] args) throws Exception {
        TextDataFileReadWrite testObj = new TextDataFileReadWrite();
        testObj.saveData();
        testObj.loadData();
    }
}
