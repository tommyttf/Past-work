import java.io.*;

class WriteBinaryFile {
   public static void main(String[] args) {
      // create a File object
      File file;
      file = new File("sample1.data");
      file = new File("Z:/Wrong BOOM FileName.data");

      try {
         // prepare a stream for the file
         boolean append = false;
         FileOutputStream out = new FileOutputStream(file, append);

         byte[] b = {11, 22, 33, 44}; // data to be written
         out.write(b);   // write data via stream

         out.close();    // close the stream

         System.out.println("Written to file " + file.getAbsolutePath());

      } catch ( FileNotFoundException e ) {
         System.out.println("File " + file.getAbsolutePath() + " cannot be opened!");
      } catch ( IOException e ) {
         System.out.println("I/O error! Program exit.");
      }
   }
}
