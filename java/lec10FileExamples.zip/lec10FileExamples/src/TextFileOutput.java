import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;

public class TextFileOutput {

    public static void main(String[] args) {
        try {
            // set up file and stream
            File file = new File("output.txt");
            PrintStream ps = new PrintStream(file);

            System.out.println("Writing to file " + file.getAbsolutePath());

            // write data to the stream
            ps.println("Hello!");
            for (int i = 0; i < 10; i++) {
                ps.printf("%d ", i);
            }
            ps.print("\n");

            ps.close(); // close stream
        } catch (FileNotFoundException e) {
            System.out.println("File cannot be opened!");
        } catch (IOException e) {
            System.out.println("I/O error! Program exit.");
        }
    }
}
