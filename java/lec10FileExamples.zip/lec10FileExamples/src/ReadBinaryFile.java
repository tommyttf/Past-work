import java.io.*;

class ReadBinaryFile {
   public static void main(String[] args) {
      // create a File object
      File file;
      file = new File("sample1.data");
      file = new File("Wrong BOOM FileName.data");

      try {
         // prepare a stream for the file
         FileInputStream in = new FileInputStream(file);

         System.out.println("Reading from file " + file.getAbsolutePath());

         // set up an array to read data in
         int fileSize = (int) file.length();
         byte[] byteArray = new byte[fileSize];

         // read the data into byteArray
         in.read(byteArray);

         // display the data
         for (int i = 0; i < fileSize; i++) {
            System.out.printf( "byteArray[%d] = %d\n", i, byteArray[i] );
         }

         // input done, so close the stream
         in.close();

      } catch ( FileNotFoundException e ) {
         System.out.println("File " + file.getAbsolutePath() + " cannot be opened!");
      } catch ( IOException e ) {
         System.out.println("I/O error! Program exit.");
      }
   }
}
