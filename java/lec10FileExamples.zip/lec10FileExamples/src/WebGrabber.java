import java.io.InputStream;
import java.util.Scanner;
import java.net.URL;

class WebGrabber
{
    public static void main(String[] args) throws Exception
    // throws exception means surrender, no try-catch
    {
        /* read from a URL as a stream */
        URL webObj;
        webObj = new URL( "http://www.google.com.hk" );
        webObj = new URL( "ftp://ftp.cse.cuhk.edu.hk" );
        InputStream in;
        in = webObj.openStream();
        Scanner reader;
        reader = new Scanner( in );
        while (reader.hasNextLine())
            System.out.println(reader.nextLine());
    } // end of main() method
} // end of class
