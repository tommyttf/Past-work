import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

class FlipBitEncryption {
   public static void main(String[] args) {
      try {
         // get source and destination filenames from user through console keyboard
         Scanner keyboard = new Scanner(System.in);
         System.out.print("Enter source file name: ");
         String src = keyboard.nextLine();
         System.out.print("Enter destination file name (be careful, it will be overwritten!) : ");
         String dest = keyboard.nextLine();

         // read source file
         File inFile = new File(src);
         FileInputStream in = new FileInputStream(inFile);

         System.out.println("Reading from file " + inFile.getAbsolutePath());

         byte[] content = new byte[(int)inFile.length()];
         in.read(content);
         in.close();

         // flip-bit: encrypt/ decrypt the binary data
         for (int i = 0; i < content.length; i++)
            content[i] += 128;

         // write destination file, with proper warning
         File outFile = new File(dest);

         if (outFile.exists())
         {
             System.out.println("File " + outFile + " exists, please answer (press <Alt>+<Tab>) pop-up dialog...");
             if (JOptionPane.showConfirmDialog(null, "Overwrite File?", "File " + outFile + " exists", JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION)
             {
                 System.out.println("User quit!  No harm done!");
                 return;
             }
         }

         FileOutputStream out = new FileOutputStream(outFile);

         System.out.println("Writing to file " + outFile.getAbsolutePath());

         out.write(content);
         out.close();

         // catch exceptions and print relevant messages, if any
      } catch (FileNotFoundException e) {
         System.out.println( e.getMessage() );
      } catch (IOException e) {
         System.out.println("I/O error! Program exit.");
      }
   }
}
