import java.io.*;
import java.util.*;

class BinaryFileBackup {
   public static void main(String[] args) {
      try {

         Scanner keyboard = new Scanner(System.in);
         System.out.print("Enter file name: ");
         String src = keyboard.nextLine();

         // read source file content into an array
         File inFile = new File(src);
         FileInputStream in = new FileInputStream(inFile);

         System.out.println("Reading from file " + inFile.getAbsolutePath());

         int fileSize = (int)inFile.length();
         byte[] content = new byte[fileSize];
         in.read(content);
         in.close();

         // write to destination
         // add .bak file extension
         File outFile = new File( src + ".bak" );
         FileOutputStream out = new FileOutputStream(outFile);

         System.out.println("Writing to file " + outFile.getAbsolutePath());

         out.write(content);
         out.close();

      } catch (FileNotFoundException e) {
         System.out.println( e.getMessage() );
      } catch (IOException e) {
         System.out.println("I/O error! Program exit.");
      }
   }
}
