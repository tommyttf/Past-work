
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class TextFileInput {

    public static void main(String[] args) {
        try {
            int x, sum = 0;
            File file = new File("sample2.txt");
            Scanner dataSource = new Scanner(file);

            System.out.println("Read from file " + file.getAbsolutePath());

            // Assume there is no input error
            // Read until end of the file is reached
            while (dataSource.hasNextInt()) {
                x = dataSource.nextInt();
                System.out.println("Read integer data in text format: " + x);
                sum += x;
            }
            dataSource.close();
            System.out.println("sum = " + sum);
        } catch (FileNotFoundException e) {
            System.out.println("File cannot be opened!");
        } catch (IOException e) {
            System.out.println("I/O error! Program exit.");
        }
    }
}
