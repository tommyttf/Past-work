
import java.io.File;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * Directory List
 * @author pffung
 *
 * Example test cases:
 * C:\
 * D:
 * hello
 * .
 * C:\Windows/Write.exe
 * build
 *
 */
public class DirectoryList {

    // another sample code for students' reference and study
    public DirectoryList() {
        // list the system folder C:/Windows/
        File systemFolder = new File("C:\\Windows");

        System.out.println(systemFolder.getAbsolutePath() + " directory listing:");

        // get directory list
        String[] systemFiles = systemFolder.list();

        // print the filenames in the directory list
        for (int i = 0; i < systemFiles.length; i++) {
            System.out.println(systemFiles[i]);
        }



        // read a pathname from user
        String pathname = JOptionPane.showInputDialog("Pathname: ");

        if (pathname == null) {
            System.out.println("User cancelled/ closed the dialog!");
        } else {
            File target = new File(pathname);

            if (target.isDirectory()) {
                System.out.println(target + " directory listing:");

                // get target list
                String[] filenames = target.list();

                // print the filenames in the target list
                for (int i = 0; i < filenames.length; i++) {
                    System.out.println(filenames[i]);
                }
            } else if (target.isFile()) {
                System.out.println(target + " is a file, not a directory!");
            } else {
                System.out.println(target + " is neither a file nor a directory!");
            }
        }
    } // end of constructor



    // slide example
    public static void main(String[] args) {
        System.out.print("Name? ");
        String pathname = new Scanner(System.in).nextLine();
        File target = new File(pathname);
        if (target.exists()) {
            if (target.isFile()) {
                System.out.println(target + " is a file.");
            } else {
                System.out.println(target + " is a dir.");
                System.out.println("Folder contents:");
                String[] fileList = target.list();
                for (int i = 0; i < fileList.length; i++) {
                    System.out.println(fileList[i]);
                }
            }
        } else {
            System.out.println(target + " doesn't exist!");
        }
    } // end of method
    
    
} // end of class

